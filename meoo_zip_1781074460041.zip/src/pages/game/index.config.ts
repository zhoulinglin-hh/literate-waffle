export default definePageConfig({
  navigationBarTitleText: '选择关卡'
});
