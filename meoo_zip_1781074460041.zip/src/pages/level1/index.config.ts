export default definePageConfig({
  navigationBarTitleText: '原料引力场'
});
