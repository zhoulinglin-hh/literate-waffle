import { View, Text, Image } from '@tarojs/components';
import Taro from '@tarojs/taro';
import { useState, useEffect, useCallback, useRef, memo } from 'react';

// 豪士logo
const HAOSHI_LOGO = 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780915493031-豪士logo.png?auth_key=aa4d28070c6764bb603388491c6c5a0cae549d5d0454ace90bdd6505304be9d0';
// 藜麦吐司
const TOAST_IMAGE = 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780915508830-藜麦吐司3.png?auth_key=29c66605c427fd584f1c97aa7b427adbc619c277692deeac24f2bb3e14473e5b';

// 原料类型
interface Ingredient {
  id: number;
  type: 'good' | 'bad';
  name: string;
  icon: string;
  x: number;
  y: number;
  speed: number;
}

const GOOD_INGREDIENTS = [
  { name: '加拿大红春麦', icon: '🌾', color: '#E96F4D' },
  { name: '青海藜麦', icon: '🌱', color: '#C7E9D0' },
  { name: '新西兰黄油', icon: '🧈', color: '#FFC65C' },
  { name: '澳洲牛奶', icon: '🥛', color: '#FFF8F0' },
];

const BAD_INGREDIENTS = [
  { name: '糖精', icon: '⚗️', color: '#999' },
  { name: '香精', icon: '🧪', color: '#666' },
];

// 原料组件 - memo优化
const IngredientItem = memo(({ ing }: { ing: Ingredient }) => (
  <View
    className="absolute w-20 h-20 rounded-full flex items-center justify-center"
    style={{
      left: `${ing.x}%`,
      top: `${ing.y}%`,
      background: ing.type === 'good'
        ? 'linear-gradient(135deg, #FFE9C7, #FFC65C)'
        : 'linear-gradient(135deg, #ccc, #999)',
      boxShadow: '0 3px 12px rgba(0,0,0,0.25)',
      transform: 'translate(-50%, -50%)'
    }}
  >
    <Text className="text-3xl">{ing.icon}</Text>
  </View>
));

const Level1Page = () => {
  const [gameState, setGameState] = useState<'ready' | 'playing' | 'paused' | 'completed'>('ready');
  const [score, setScore] = useState(0);
  const [collected, setCollected] = useState<string[]>([]);
  const [trayX, setTrayX] = useState(50);
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [showSlogan, setShowSlogan] = useState(false);
  const [sloganText, setSloganText] = useState('');
  const [showEncouragement, setShowEncouragement] = useState(false);
  const [encouragementText, setEncouragementText] = useState('');
  const [hasShownStartEncouragement, setHasShownStartEncouragement] = useState(false);

  // 使用ref来存储游戏状态，避免闭包问题
  const gameStateRef = useRef(gameState);
  const trayXRef = useRef(trayX);
  const collectedRef = useRef(collected);
  const ingredientsRef = useRef(ingredients);

  const gameLoopRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const spawnRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // 触摸相关ref - 用于流畅移动
  const gameAreaRef = useRef<{ left: number; width: number } | null>(null);
  const rafRef = useRef<number | null>(null);
  const touchXRef = useRef<number | null>(null);

  // 同步ref
  useEffect(() => { gameStateRef.current = gameState; }, [gameState]);
  useEffect(() => { trayXRef.current = trayX; }, [trayX]);
  useEffect(() => { collectedRef.current = collected; }, [collected]);
  useEffect(() => { ingredientsRef.current = ingredients; }, [ingredients]);

  // 生成原料
  const spawnIngredient = useCallback(() => {
    // 游戏暂停时（如显示鼓励文案）不生成原料
    if (gameStateRef.current !== 'playing' || showEncouragement) return;
    
    const isGood = Math.random() > 0.3;
    const template = isGood 
      ? GOOD_INGREDIENTS[Math.floor(Math.random() * GOOD_INGREDIENTS.length)]
      : BAD_INGREDIENTS[Math.floor(Math.random() * BAD_INGREDIENTS.length)];
    
    const newIngredient: Ingredient = {
      id: Date.now() + Math.random(),
      type: isGood ? 'good' : 'bad',
      name: template.name,
      icon: template.icon,
      x: Math.random() * 80 + 10,
      y: -10,
      speed: (Math.random() * 1 + 1) * 0.55, // 减慢45%
    };
    
    setIngredients(prev => [...prev, newIngredient]);
  }, []);

  // 游戏循环 - 使用ref避免依赖问题
  useEffect(() => {
    if (gameState === 'playing') {
      // 游戏主循环 - 60fps
      gameLoopRef.current = setInterval(() => {
        // 显示鼓励文案时暂停游戏（原料不下落）
        if (showEncouragement) return;

        const currentIngredients = ingredientsRef.current;
        const currentTrayX = trayXRef.current;
        const currentCollected = collectedRef.current;

        setIngredients(prev => {
          const updated = prev.map(ing => ({
            ...ing,
            y: ing.y + ing.speed
          })).filter(ing => ing.y < 110);

          // 检查碰撞
          const trayLeft = currentTrayX - 15;
          const trayRight = currentTrayX + 15;

          const remaining: Ingredient[] = [];
          updated.forEach(ing => {
            if (ing.y > 82 && ing.y < 95 && ing.x > trayLeft && ing.x < trayRight) {
              // 碰撞检测
              if (ing.type === 'good') {
                if (!currentCollected.includes(ing.name)) {
                  setCollected(c => [...c, ing.name]);
                  setScore(s => s + 10);
                  showFloatingText('豪～');
                }
              } else {
                showFloatingText('呸！');
                Taro.vibrateShort({ type: 'light' });
              }
            } else {
              remaining.push(ing);
            }
          });

          return remaining;
        });
      }, 16); // 60fps

      // 生成原料 - 使用setTimeout递归代替setInterval，确保能读取最新的showEncouragement状态
      const spawnLoop = () => {
        if (gameStateRef.current === 'playing' && !showEncouragement) {
          spawnIngredient();
        }
        if (gameStateRef.current === 'playing') {
          spawnRef.current = setTimeout(spawnLoop, 800) as unknown as ReturnType<typeof setInterval>;
        }
      };
      spawnLoop();
    } else {
      if (gameLoopRef.current) clearInterval(gameLoopRef.current);
      if (spawnRef.current) clearTimeout(spawnRef.current as unknown as NodeJS.Timeout);
    }

    return () => {
      if (gameLoopRef.current) clearInterval(gameLoopRef.current);
      if (spawnRef.current) clearTimeout(spawnRef.current as unknown as NodeJS.Timeout);
    };
  }, [gameState, showEncouragement, spawnIngredient]);

  // 检查游戏完成
  useEffect(() => {
    if (collected.length >= 4 && gameState === 'playing') {
      setGameState('completed');
      saveProgress();
      // 显示完成鼓励文案（需要手动关闭）
      setEncouragementText('一下子选错了也没关系，面包的生活有很大的容错率。如果一下子就选对了，那你真的超级厉害。');
      setShowEncouragement(true);
    }
  }, [collected, gameState]);

  const showFloatingText = (text: string) => {
    setSloganText(text);
    setShowSlogan(true);
    setTimeout(() => setShowSlogan(false), 800);
  };

  const saveProgress = () => {
    const progress = Taro.getStorageSync('gameProgress');
    const data = progress ? JSON.parse(progress) : { levels: [], score: 0 };
    data.levels = data.levels || [];
    data.levels[0] = { id: 1, completed: true, unlocked: true };
    data.levels[1] = { id: 2, completed: false, unlocked: true };
    data.score = (data.score || 0) + score;
    Taro.setStorageSync('gameProgress', JSON.stringify(data));
  };

  const startGame = () => {
    setGameState('playing');
    setScore(0);
    setCollected([]);
    setIngredients([]);
    // 初始化游戏区域尺寸
    initGameArea();
    // 显示开始鼓励文案（暂停游戏，2秒后自动恢复）
    if (!hasShownStartEncouragement) {
      setHasShownStartEncouragement(true);
      setEncouragementText('你不需要一次性集齐所有答案，随手拿起麦粉、藜麦……就像你今天愿意开始，就已经很了不起。');
      setShowEncouragement(true);
      // 2秒后自动关闭鼓励文案，游戏恢复
      setTimeout(() => {
        setShowEncouragement(false);
      }, 2000);
    }
  };

  // 手动关闭鼓励文案
  const closeEncouragement = () => {
    setShowEncouragement(false);
  };

  // 初始化游戏区域尺寸 - 用于全品类手机兼容
  const initGameArea = useCallback(() => {
    // 使用Taro获取系统信息，确保跨端兼容
    const systemInfo = Taro.getSystemInfoSync();
    const windowWidth = systemInfo.windowWidth || 375;
    // 游戏区域左右边距各为8 (px-4 = 16px = 1rem ≈ 16px)
    const padding = 16;
    gameAreaRef.current = {
      left: padding,
      width: windowWidth - padding * 2
    };
  }, []);

  // 使用requestAnimationFrame更新托盘位置 - 确保流畅度
  const updateTrayPosition = useCallback(() => {
    if (touchXRef.current !== null && gameAreaRef.current) {
      const x = ((touchXRef.current - gameAreaRef.current.left) / gameAreaRef.current.width) * 100;
      setTrayX(Math.max(15, Math.min(85, x)));
    }
    rafRef.current = null;
  }, []);

  // 触摸开始 - 初始化位置
  const handleTouchStart = useCallback((e: any) => {
    if (gameStateRef.current !== 'playing') return;
    // 延迟初始化以确保获取正确尺寸
    if (!gameAreaRef.current) {
      initGameArea();
    }
    const touch = e.touches[0];
    touchXRef.current = touch.clientX;
    // 立即更新一次位置
    if (gameAreaRef.current) {
      const x = ((touch.clientX - gameAreaRef.current.left) / gameAreaRef.current.width) * 100;
      setTrayX(Math.max(15, Math.min(85, x)));
    }
  }, [initGameArea]);

  // 触摸移动 - 使用RAF优化流畅度
  const handleTouchMove = useCallback((e: any) => {
    if (gameStateRef.current !== 'playing') return;
    const touch = e.touches[0];
    touchXRef.current = touch.clientX;
    // 使用requestAnimationFrame确保流畅更新
    if (!rafRef.current) {
      rafRef.current = requestAnimationFrame(updateTrayPosition);
    }
  }, [updateTrayPosition]);

  // 触摸结束 - 清理
  const handleTouchEnd = useCallback(() => {
    touchXRef.current = null;
    if (rafRef.current) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
  }, []);

  // 组件卸载时清理
  useEffect(() => {
    return () => {
      if (rafRef.current) {
        cancelAnimationFrame(rafRef.current);
      }
    };
  }, []);

  const nextLevel = () => {
    Taro.redirectTo({ url: '/pages/level2/index' });
  };

  const backToMenu = () => {
    Taro.redirectTo({ url: '/pages/game/index' });
  };

  return (
    <View className="min-h-screen w-full flex flex-col bg-background relative overflow-hidden">
      {/* 顶部导航 */}
      <View className="flex items-center justify-between px-4 py-3 bg-wheat-yellow">
        <View className="flex items-center" onClick={backToMenu}>
          <Image src={HAOSHI_LOGO} className="w-24 h-12 object-contain" mode="aspectFit" />
        </View>
        <View className="flex items-center gap-2">
          <Text className="text-gold text-xl">🪙</Text>
          <Text className="text-dark-brown font-bold">{score}</Text>
        </View>
      </View>

      {/* 关卡标题 */}
      <View className="flex flex-col items-center py-4 bg-gradient-to-b from-wheat-yellow to-background">
        <Text className="text-dark-brown text-2xl font-bold">关卡 1</Text>
        <Text className="text-quinoa-red text-xl font-bold">原料引力场</Text>
        <Text className="text-light-brown text-sm mt-1">收集全球精选食材</Text>
      </View>

      {/* 游戏区域 */}
      <View
        className="flex-1 relative overflow-hidden"
        onTouchMove={handleTouchMove}
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        {/* 原料星球 */}
        <View 
          className="absolute top-10 right-10 w-20 h-20 rounded-full opacity-30"
          style={{ background: 'linear-gradient(135deg, #C7E9D0, #FFE9C7)' }}
        />
        <View 
          className="absolute top-20 left-8 w-16 h-16 rounded-full opacity-25"
          style={{ background: 'linear-gradient(135deg, #FFC65C, #E96F4D)' }}
        />

        {/* 收集进度 */}
        <View className="absolute top-4 left-2 right-2">
          <Text className="text-dark-brown text-base font-bold mb-2 text-center">收集进度</Text>
          <View className="flex justify-between">
            {GOOD_INGREDIENTS.map((ing) => (
              <View
                key={ing.name}
                className={`w-16 h-16 rounded-xl flex items-center justify-center flex-1 mx-1 ${
                  collected.includes(ing.name) ? 'bg-cream-green' : 'bg-muted'
                }`}
              >
                <Text className="text-3xl">{collected.includes(ing.name) ? ing.icon : '?'}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* 掉落的原料 */}
        {ingredients.map(ing => (
          <IngredientItem key={ing.id} ing={ing} />
        ))}

        {/* 魔法托盘 */}
        <View 
          className="absolute bottom-20 w-24 h-12 rounded-full flex items-center justify-center"
          style={{
            left: `${trayX}%`,
            transform: 'translateX(-50%)',
            background: 'linear-gradient(135deg, #E96F4D, #FFC65C)',
            boxShadow: '0 4px 12px rgba(233,111,77,0.4)'
          }}
        >
          <Text className="text-white text-2xl">🤲</Text>
        </View>

        {/* 吐司宝宝提示 */}
        <View className="absolute bottom-4 right-4">
          <Image 
            src={TOAST_IMAGE} 
            className="w-16 h-16 object-contain"
            mode="aspectFit"
            style={{ animation: 'bounce-soft 2s ease-in-out infinite' }}
          />
        </View>

        {/* 浮动文字 */}
        {showSlogan && (
          <View
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2"
            style={{ animation: 'pop-in 0.3s ease-out' }}
          >
            <Text
              className="text-quinoa-red text-3xl font-bold"
              style={{ textShadow: '2px 2px 4px rgba(0,0,0,0.3)' }}
            >
              {sloganText}
            </Text>
          </View>
        )}

        {/* 鼓励文案弹窗 - 显示在关卡介绍正下方，点击关闭 */}
        {showEncouragement && (
          <View
            className="absolute top-28 left-4 right-4 z-50"
            style={{ animation: 'pop-in 0.5s ease-out' }}
            onClick={closeEncouragement}
          >
            <View
              className="bg-white rounded-2xl p-4 shadow-lg"
              style={{
                backgroundColor: 'rgba(255,255,255,0.95)',
                boxShadow: '0 4px 20px rgba(0,0,0,0.15)'
              }}
            >
              <Text className="text-dark-brown text-sm text-center leading-relaxed">
                {encouragementText}
              </Text>
              <Text className="text-light-brown text-xs text-center mt-2">点击关闭</Text>
            </View>
          </View>
        )}

        {/* 开始遮罩 */}
        {gameState === 'ready' && (
          <View
            className="absolute inset-0 flex items-center justify-center"
            style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}
          >
            <View className="bg-white rounded-3xl p-8 flex flex-col items-center">
              <Text className="text-4xl mb-4">🌾</Text>
              <Text className="text-dark-brown text-lg font-bold mb-2">原料引力场</Text>
              <Text className="text-light-brown text-sm mb-6 text-center">
                移动魔法托盘接住{'\n'}加拿大红春麦、青海藜麦、{'\n'}新西兰黄油、澳洲牛奶{'\n'}避开糖精和香精！
              </Text>
              <View 
                className="px-8 py-3 rounded-full"
                style={{ background: 'linear-gradient(135deg, #E96F4D, #FFC65C)' }}
                onClick={startGame}
              >
                <Text className="text-white font-bold">开始游戏</Text>
              </View>
            </View>
          </View>
        )}

        {/* 完成遮罩 */}
        {gameState === 'completed' && (
          <View
            className="absolute inset-0 flex items-center justify-center"
            style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}
          >
            <View className="bg-white rounded-3xl p-8 flex flex-col items-center">
              <Text className="text-4xl mb-4">🎉</Text>
              <Text className="text-dark-brown text-lg font-bold mb-2">关卡完成！</Text>
              <Text 
                className="text-quinoa-red text-xl font-bold mb-4"
                style={{ animation: 'slogan-bounce 1s ease-in-out infinite' }}
              >
                豪士豪士，好吃好吃
              </Text>
              <Text className="text-light-brown text-sm mb-6">
                获得 {score} 金币
              </Text>
              <View 
                className="px-8 py-3 rounded-full mb-3"
                style={{ background: 'linear-gradient(135deg, #E96F4D, #FFC65C)' }}
                onClick={nextLevel}
              >
                <Text className="text-white font-bold">下一关</Text>
              </View>
              <View 
                className="px-8 py-3 rounded-full bg-muted"
                onClick={backToMenu}
              >
                <Text className="text-dark-brown">返回菜单</Text>
              </View>
            </View>
          </View>
        )}
      </View>
    </View>
  );
};

export default Level1Page;
