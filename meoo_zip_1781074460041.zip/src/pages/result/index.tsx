import { View, Text, Image } from '@tarojs/components';
import Taro from '@tarojs/taro';
import { useState, useEffect } from 'react';

// 豪士logo
const HAOSHI_LOGO = 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780915493031-豪士logo.png?auth_key=aa4d28070c6764bb603388491c6c5a0cae549d5d0454ace90bdd6505304be9d0';
// 藜麦吐司
const TOAST_IMAGE = 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780915508830-藜麦吐司3.png?auth_key=29c66605c427fd584f1c97aa7b427adbc619c277692deeac24f2bb3e14473e5b';

// 透明工厂图片
const FACTORY_IMAGES = [
  { 
    url: 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780917532391-36米压面轨道1.png?auth_key=5b9a527ab2a55db54dacef900f8dcf79f53b5c7c4603e8a1658c5688ebebb46b',
    name: '36米压面轨道'
  },
  { 
    url: 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780917532397-36米压面轨道2.png?auth_key=44aa906dc60f926309c0e23d1b40f0f456795fd2cc3a2ad5ea91a77a90eca841',
    name: '压面轨道全景'
  },
  { 
    url: 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780917532402-出面团轨道.png?auth_key=fc1458d5e4b46f528e2557c6c73c7c09bce84dca18a772afb922ae07abd622f8',
    name: '出面团轨道'
  },
  { 
    url: 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780917532403-分面机.png?auth_key=46b52c42e0f76aea82e74a5ceb5a409a81a51de797fff98a34320ba8e9ca00a7',
    name: '分面机'
  },
  { 
    url: 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780917532408-烘烤后出炉运送.png?auth_key=f6fff137bb007df8ac3b2523360fb7f7a01878210215e2af15bbcb56ef9ea4d6',
    name: '烘烤出炉'
  },
  { 
    url: 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780917532410-烘烤后出炉运送2.png?auth_key=7679a9614a064b249d201b152ed1f604d537959788e0bb42d04f95af971d351d',
    name: '出炉运送'
  },
  { 
    url: 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780917532416-面包塔.png?auth_key=5a6c353a107558db967edc7e0410eca93bd4d76de8ce323a0f37f659f888190e',
    name: '螺旋烘焙塔'
  },
  { 
    url: 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780917532422-面团切割.png?auth_key=7e47fb46107754832c057a771854a9537490963a3ee48597a4bbe710d4b19ff6',
    name: '面团切割'
  },
  { 
    url: 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780917532428-切割.png?auth_key=461c598c8fb0c265540872214be1265727161ccaa2a8ffc1fd3f1706beea7dbf',
    name: '精准切割'
  },
  { 
    url: 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780917532428-装箱.png?auth_key=15665a1627365f1a2cb3c3f051749d4d6e837f0d2fa2dfc0155fbb34ca774bdf',
    name: '自动装箱'
  },
];

const TITLES = [
  { min: 0, title: '见习烘焙师', icon: '👶' },
  { min: 100, title: '去边高手', icon: '🔪' },
  { min: 200, title: '黄金烘焙师', icon: '👨‍🍳' },
  { min: 300, title: '藜麦吐司大师', icon: '👑' },
];

const COUPONS = [
  { value: 5, desc: '无门槛优惠券', icon: '🎫' },
  { value: 10, desc: '满50减10', icon: '🎟️' },
  { value: 20, desc: '满100减20', icon: '💰' },
];

const ResultPage = () => {
  const [totalScore, setTotalScore] = useState(0);
  const [title, setTitle] = useState(TITLES[0]);
  const [showConfetti, setShowConfetti] = useState(false);
  const [coupon, setCoupon] = useState<typeof COUPONS[0] | null>(null);
  const [showCoupon, setShowCoupon] = useState(false);
  const [selectedImage, setSelectedImage] = useState<{url: string; name: string} | null>(null);
  const [showShop, setShowShop] = useState(false);
  const [purchasedBlessings, setPurchasedBlessings] = useState<number[]>([]);
  const [showEncouragement, setShowEncouragement] = useState(false);
  const [encouragementText, setEncouragementText] = useState('');

  // 祝福商品列表
  const BLESSINGS = [
    { id: 1, name: '祝福1', content: '吃豪士，出门遇好事！', price: 75, icon: '🍀' },
    { id: 2, name: '祝福2', content: '美味豪士，美事好事！', price: 75, icon: '😋' },
    { id: 3, name: '祝福3', content: '吃豪士，豪开心！', price: 75, icon: '😄' },
    { id: 4, name: '祝福4', content: '吃豪士，豪幸运马上降临！', price: 75, icon: '✨' },
  ];

  useEffect(() => {
    const progress = Taro.getStorageSync('gameProgress');
    if (progress) {
      const data = JSON.parse(progress);
      const score = data.score || 0;
      setTotalScore(score);
      setPurchasedBlessings(data.purchasedBlessings || []);

      const earnedTitle = TITLES.slice().reverse().find(t => score >= t.min) || TITLES[0];
      setTitle(earnedTitle);

      data.levels = data.levels || [];
      data.levels[3] = { id: 4, completed: true, unlocked: true };
      Taro.setStorageSync('gameProgress', JSON.stringify(data));
    }

    setTimeout(() => setShowConfetti(true), 500);

    // 检查是否从关卡3完成跳转过来，2秒后显示商店和鼓励文案
    const router = Taro.getCurrentInstance().router;
    if (router?.params?.showShop === 'true') {
      setTimeout(() => {
        setShowShop(true);
        // 伴随商店显示鼓励文案
        setEncouragementText('工厂有它的标准，但你可以做独一无二的吐司。包装只是外衣，拆开以后才是真正的你。');
        setShowEncouragement(true);
      }, 2000);
    }
  }, []);

  const purchaseBlessing = (blessing: typeof BLESSINGS[0]) => {
    if (totalScore < blessing.price) {
      Taro.showToast({ title: '金币不足', icon: 'none' });
      return;
    }
    if (purchasedBlessings.includes(blessing.id)) {
      Taro.showToast({ title: '已兑换过该祝福', icon: 'none' });
      return;
    }

    const newScore = totalScore - blessing.price;
    const newPurchased = [...purchasedBlessings, blessing.id];
    setTotalScore(newScore);
    setPurchasedBlessings(newPurchased);

    const savedProgress = Taro.getStorageSync('gameProgress');
    const data = savedProgress ? JSON.parse(savedProgress) : {};
    data.score = newScore;
    data.purchasedBlessings = newPurchased;
    Taro.setStorageSync('gameProgress', JSON.stringify(data));

    Taro.showToast({ title: `获得${blessing.name}！`, icon: 'success' });

    if (newPurchased.length === BLESSINGS.length) {
      setTimeout(() => setShowShop(false), 1500);
    }
  };

  const closeShop = () => {
    setShowShop(false);
    // 关闭商店时同时关闭鼓励文案
    setShowEncouragement(false);
  };

  const drawCoupon = () => {
    const random = Math.random();
    let selected;
    if (random < 0.5) {
      selected = COUPONS[0];
    } else if (random < 0.8) {
      selected = COUPONS[1];
    } else {
      selected = COUPONS[2];
    }
    setCoupon(selected);
    setShowCoupon(true);
  };

  const resetGame = () => {
    Taro.removeStorageSync('gameProgress');
    Taro.redirectTo({ url: '/pages/index/index' });
  };

  const backToMenu = () => {
    Taro.redirectTo({ url: '/pages/game/index' });
  };

  const openImage = (image: {url: string; name: string}) => {
    setSelectedImage(image);
  };

  const closeImage = () => {
    setSelectedImage(null);
  };

  return (
    <View className="min-h-screen w-full flex flex-col bg-background relative overflow-hidden">
      {/* 彩纸效果 */}
      {showConfetti && (
        <View className="absolute inset-0 pointer-events-none overflow-hidden">
          {[...Array(20)].map((_, i) => (
            <View
              key={i}
              className="absolute w-2 h-2 rounded-sm"
              style={{
                left: `${Math.random() * 100}%`,
                background: ['#E96F4D', '#FFC65C', '#C7E9D0', '#FFE9C7'][Math.floor(Math.random() * 4)],
                animation: `confetti-fall ${2 + Math.random() * 2}s linear forwards`,
                animationDelay: `${Math.random() * 2}s`,
                transform: `rotate(${Math.random() * 360}deg)`
              }}
            />
          ))}
        </View>
      )}

      {/* 鼓励文案弹窗 */}
      {showEncouragement && (
        <View className="absolute top-24 left-4 right-4 z-50" style={{ animation: 'pop-in 0.5s ease-out' }}>
          <View className="bg-white rounded-2xl p-4 shadow-lg" style={{ backgroundColor: 'rgba(255,255,255,0.95)', boxShadow: '0 4px 20px rgba(0,0,0,0.15)' }}>
            <Text className="text-dark-brown text-sm text-center leading-relaxed">{encouragementText}</Text>
          </View>
        </View>
      )}

      {/* 顶部导航 */}
      <View className="flex items-center justify-between px-4 py-3 bg-wheat-yellow">
        <View className="flex items-center" onClick={backToMenu}>
          <Image src={HAOSHI_LOGO} className="w-24 h-12 object-contain" mode="aspectFit" />
        </View>
        <View className="flex items-center gap-2">
          <Text className="text-gold text-xl">🪙</Text>
          <Text className="text-dark-brown font-bold">{totalScore}</Text>
        </View>
      </View>

      {/* 主内容 - 使用flex布局 */}
      <View className="flex-1 flex flex-col items-center px-6 py-2">
        {/* 标题 */}
        <View className="flex flex-col items-center py-4">
          <Text className="text-dark-brown text-2xl font-bold">关卡 4</Text>
          <Text className="text-quinoa-red text-xl font-bold">分享工厂狂欢</Text>
          <Text className="text-light-brown text-sm mt-1">分享你的烘焙成果</Text>
        </View>

        {/* 成品展示 */}
        <View className="relative mb-4">
          <View 
            className="absolute inset-0 rounded-full"
            style={{
              background: 'radial-gradient(circle, rgba(255,198,92,0.3) 0%, transparent 70%)',
              animation: 'float 3s ease-in-out infinite'
            }}
          />
          
          <View 
            className="w-40 h-40 rounded-full flex items-center justify-center relative"
            style={{
              background: 'radial-gradient(circle, rgba(255,233,199,0.8) 0%, rgba(255,233,199,0) 70%)',
              animation: 'bounce-soft 2s ease-in-out infinite'
            }}
          >
            <Image 
              src={TOAST_IMAGE}
              className="w-32 h-32 object-contain"
              mode="aspectFit"
            />
            <View className="absolute -top-1">
              <Text className="text-2xl">👑</Text>
            </View>
          </View>

          <View className="absolute -top-2 right-0" style={{ animation: 'sparkle 1.5s ease-in-out infinite' }}>
            <Text className="text-xl">✨</Text>
          </View>
          <View className="absolute top-8 -left-4" style={{ animation: 'sparkle 1.5s ease-in-out infinite 0.5s' }}>
            <Text className="text-lg">⭐</Text>
          </View>
        </View>

        {/* 称号 */}
        <View 
          className="px-5 py-2 rounded-full mb-3"
          style={{ 
            background: 'linear-gradient(90deg, #E96F4D, #FFC65C)',
            animation: 'pop-in 0.5s ease-out' 
          }}
        >
          <Text className="text-white text-base font-bold">
            {title.icon} {title.title}
          </Text>
        </View>

        {/* Slogan */}
        <Text
          className="text-quinoa-red text-xl font-bold mb-4"
          style={{
            textShadow: '2px 2px 4px rgba(255,198,92,0.5)',
            animation: 'slogan-bounce 1s ease-in-out infinite'
          }}
        >
          豪士豪士，好吃好吃
        </Text>

        {/* 最终鼓励文案 */}
        <View
          className="px-4 py-3 rounded-xl mb-4"
          style={{
            background: 'linear-gradient(135deg, rgba(255,233,199,0.6), rgba(255,198,92,0.3))',
            border: '1px solid rgba(255,198,92,0.5)'
          }}
        >
          <Text className="text-dark-brown text-sm text-center leading-relaxed">
            豪士豪士，好吃好吃。和你一样，独一无二。
          </Text>
        </View>

        {/* 透明工厂展示 - 可点击放大 */}
        <View className="w-full mb-4">
          <Text className="text-dark-brown text-sm font-bold mb-2">透明工厂 · 品质看得见（点击图片查看）</Text>
          <View className="flex gap-2 overflow-x-auto pb-2">
            {FACTORY_IMAGES.map((img, idx) => (
              <View 
                key={idx} 
                className="w-24 h-24 rounded-xl overflow-hidden flex-shrink-0 cursor-pointer"
                style={{ border: '2px solid #FFE9C7' }}
                onClick={() => openImage(img)}
              >
                <Image src={img.url} className="w-full h-full object-cover" mode="aspectFill" />
              </View>
            ))}
          </View>
        </View>

        {/* 按钮组 */}
        <View className="w-full flex flex-col gap-2">
          <View
            className="w-full py-2 rounded-full flex items-center justify-center"
            style={{ backgroundColor: '#F5E2D1' }}
            onClick={resetGame}
          >
            <Text className="text-dark-brown text-sm">再玩一次</Text>
          </View>
        </View>
      </View>

      {/* 优惠券弹窗 */}
      {showCoupon && coupon && (
        <View
          className="absolute inset-0 flex items-center justify-center z-50"
          style={{ backgroundColor: 'rgba(0,0,0,0.6)' }}
        >
          <View 
            className="bg-white rounded-3xl p-6 flex flex-col items-center mx-6"
            style={{ animation: 'pop-in 0.3s ease-out' }}
          >
            <Text className="text-4xl mb-3">{coupon.icon}</Text>
            <Text className="text-dark-brown text-lg font-bold mb-2">恭喜获得</Text>
            <View 
              className="px-5 py-2 rounded-xl mb-3"
              style={{ background: 'linear-gradient(90deg, #E96F4D, #FFC65C)' }}
            >
              <Text className="text-white text-2xl font-bold">¥{coupon.value}</Text>
            </View>
            <Text className="text-light-brown text-sm mb-4">{coupon.desc}</Text>
            <View 
              className="px-6 py-2 rounded-full"
              style={{ background: 'linear-gradient(135deg, #E96F4D, #FFC65C)' }}
              onClick={() => setShowCoupon(false)}
            >
              <Text className="text-white font-bold">收下优惠券</Text>
            </View>
          </View>
        </View>
      )}

      {/* 图片放大查看弹窗 */}
      {selectedImage && (
        <View
          className="absolute inset-0 flex items-center justify-center z-50"
          style={{ backgroundColor: 'rgba(0,0,0,0.85)' }}
          onClick={closeImage}
        >
          <View className="flex flex-col items-center mx-4">
            <Image
              src={selectedImage.url}
              className="w-80 h-80 rounded-xl object-cover"
              mode="aspectFit"
            />
            <Text className="text-white text-lg font-bold mt-4">{selectedImage.name}</Text>
            <Text className="text-sm mt-2" style={{ color: 'rgba(255,255,255,0.7)' }}>点击任意位置关闭</Text>
          </View>
        </View>
      )}

      {/* 商店弹窗 */}
      {showShop && (
        <View
          className="absolute inset-0 flex items-center justify-center z-50"
          style={{ backgroundColor: 'rgba(0,0,0,0.6)' }}
        >
          <View
            className="bg-white rounded-3xl p-6 flex flex-col items-center mx-4 max-w-sm"
            style={{ animation: 'pop-in 0.3s ease-out' }}
          >
            {/* 商店标题 */}
            <View className="flex items-center gap-2 mb-4">
              <Text className="text-3xl">🛒</Text>
              <Text className="text-dark-brown text-xl font-bold">豪士祝福商店</Text>
              <Text className="text-3xl">🛒</Text>
            </View>

            {/* 当前金币 */}
            <View
              className="flex items-center gap-2 px-4 py-2 rounded-full mb-4"
              style={{ background: 'linear-gradient(90deg, #FFE9C7, #FFC65C)' }}
            >
              <Text className="text-xl">🪙</Text>
              <Text className="text-dark-brown font-bold">{totalScore} 金币</Text>
            </View>

            {/* 祝福列表 */}
            <View className="w-full space-y-3 mb-4">
              {BLESSINGS.map((blessing) => {
                const isPurchased = purchasedBlessings.includes(blessing.id);
                return (
                  <View
                    key={blessing.id}
                    className={`w-full p-3 rounded-xl border-2 ${
                      isPurchased ? 'border-cream-green bg-green-50' : 'border-wheat-yellow'
                    }`}
                    style={{
                      background: isPurchased ? '#F0FDF4' : 'linear-gradient(135deg, #FFF8F0, #FFE9C7)',
                    }}
                  >
                    <View className="flex items-center justify-between">
                      <View className="flex items-center gap-2 flex-1">
                        <Text className="text-2xl">{blessing.icon}</Text>
                        <View className="flex-1">
                          <Text className="text-dark-brown font-bold text-sm">{blessing.name}</Text>
                          <Text className="text-light-brown text-xs">{blessing.content}</Text>
                        </View>
                      </View>
                      <View
                        className={`px-3 py-1 rounded-full ${
                          isPurchased
                            ? 'bg-cream-green'
                            : totalScore >= blessing.price
                            ? 'bg-quinoa-red'
                            : 'bg-gray-300'
                        }`}
                        onClick={() => !isPurchased && purchaseBlessing(blessing)}
                      >
                        <Text className="text-white text-xs font-bold">
                          {isPurchased ? '已兑换' : `${blessing.price}🪙`}
                        </Text>
                      </View>
                    </View>
                  </View>
                );
              })}
            </View>

            {/* 关闭按钮 */}
            <View
              className="px-6 py-2 rounded-full"
              style={{ background: 'linear-gradient(135deg, #E96F4D, #FFC65C)' }}
              onClick={closeShop}
            >
              <Text className="text-white font-bold">关闭商店</Text>
            </View>
          </View>
        </View>
      )}
    </View>
  );
};

export default ResultPage;
