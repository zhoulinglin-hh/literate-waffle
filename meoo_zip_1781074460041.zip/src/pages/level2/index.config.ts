export default definePageConfig({
  navigationBarTitleText: '去边魔术秀'
});
