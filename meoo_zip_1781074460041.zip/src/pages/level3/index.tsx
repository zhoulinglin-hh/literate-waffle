import { View, Text, Image } from '@tarojs/components';
import Taro from '@tarojs/taro';
import { useState, useEffect, useRef, useCallback, memo } from 'react';

// 豪士logo
const HAOSHI_LOGO = 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780915493031-豪士logo.png?auth_key=aa4d28070c6764bb603388491c6c5a0cae549d5d0454ace90bdd6505304be9d0';
// 藜麦吐司
const TOAST_IMAGE = 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780915508830-藜麦吐司3.png?auth_key=29c66605c427fd584f1c97aa7b427adbc619c277692deeac24f2bb3e14473e5b';

// 工厂工序背景图
const DOUGH_BG = 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780926491343-分面机.png?auth_key=5c73da878e6f064be011f3cd4867893cb172f3cb9f72e6151b98dfbc93e67ad8';
const PRESS_BG = 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780926491326-36米压面轨道1.png?auth_key=2154f56a8adfa2d466880227410e46e4692c1222c36e0bbe4edd0c0a717f43d5';
const CUT_BG = 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780926491359-面团切割.png?auth_key=2168c18443ef9ba1411c9848b4b2f48193068820543822dce0e1390132d9cd39';
const BAKE_BG = 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780926491357-面包塔.png?auth_key=713d01889769e281174680db48673b273eccbf04f56619ab18745523ec994246';
const COOL_BG = 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780926491351-烘烤后出炉运送.png?auth_key=4d6cc198ad262dfbe5fe75058ce65ced58863dbcd11d80fa2a90e2b9a6787ea5';
const PACKAGE_BG = 'https://conversation.cdn.meoo.host/conversations/315421230268350464/image/2026-06-08/1780926491370-装箱.png?auth_key=c9e6dd561f3173febdb83cefca0a95f580eeec5aa61faa1548ed9c02654d8122';

// 流水线阶段类型
type StageType = 'dough' | 'press' | 'cut' | 'bake' | 'cool' | 'package';

interface Stage {
  id: StageType;
  name: string;
  icon: string;
  desc: string;
  progress: number;
  completed: boolean;
}

const STAGES_CONFIG: Stage[] = [
  { id: 'dough', name: '和面', icon: '🥣', desc: '高速卧式和面机', progress: 0, completed: false },
  { id: 'press', name: '压面', icon: '🫓', desc: '36米压面轨道', progress: 0, completed: false },
  { id: 'cut', name: '切割', icon: '✂️', desc: '精准面团切割', progress: 0, completed: false },
  { id: 'bake', name: '烘焙', icon: '🔥', desc: '螺旋烘焙塔', progress: 0, completed: false },
  { id: 'cool', name: '冷却', icon: '🌬️', desc: '智能冷却系统', progress: 0, completed: false },
  { id: 'package', name: '包装', icon: '📦', desc: '自动装箱线', progress: 0, completed: false },
];

// ==================== 和面工序组件 ====================
// 搅拌棒emoji在碗里画圈旋转，面团颜色从浅黄变深黄
const DoughStage = memo(({ progress, onProgressChange }: { progress: number; onProgressChange: (p: number) => void }) => {
  const [stirrerAngle, setStirrerAngle] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const lastAngleRef = useRef(0);
  const centerRef = useRef({ x: 0, y: 0 });

  // 面团颜色：浅黄 #FFF8DC -> 深黄 #D4A574
  const doughColor = `rgb(${255 - Math.floor(progress * 0.33)}, ${248 - Math.floor(progress * 1.16)}, ${220 - Math.floor(progress * 1.08)})`;

  const getAngle = (clientX: number, clientY: number) => {
    const dx = clientX - centerRef.current.x;
    const dy = clientY - centerRef.current.y;
    return Math.atan2(dy, dx) * (180 / Math.PI);
  };

  const handleTouchStart = (e: any) => {
    const touch = e.touches[0];
    // 设置碗中心点 - 使用固定值避免小程序环境window对象问题
    centerRef.current = { x: 200, y: 280 };
    lastAngleRef.current = getAngle(touch.clientX, touch.clientY);
    setIsDragging(true);
  };

  const handleTouchMove = (e: any) => {
    if (!isDragging) return;
    const touch = e.touches[0];
    const currentAngle = getAngle(touch.clientX, touch.clientY);
    let delta = currentAngle - lastAngleRef.current;

    // 处理角度跳变
    if (delta > 180) delta -= 360;
    if (delta < -180) delta += 360;

    // 只响应顺时针旋转，2圈满100% (360*2=720度)
    if (delta > 0) {
      setStirrerAngle(prev => prev + delta);
      const newProgress = Math.min(100, progress + delta / 7.2);
      onProgressChange(newProgress);
    }
    lastAngleRef.current = currentAngle;
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };

  // 计算搅拌棒位置（在碗内画圈）
  const stirrerX = Math.cos((stirrerAngle * Math.PI) / 180) * 30;
  const stirrerY = Math.sin((stirrerAngle * Math.PI) / 180) * 20;

  return (
    <View className="w-full flex flex-col items-center">
      <Text className="text-dark-brown text-sm mb-2">用搅拌棒顺时针画圈和面</Text>
      <View
        className="relative w-full h-56 flex items-center justify-center overflow-hidden rounded-xl"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* 背景图 - 分面机 */}
        <Image
          src={DOUGH_BG}
          className="absolute inset-0 w-full h-full"
          mode="aspectFill"
        />
        {/* 半透明遮罩 */}
        <View className="absolute inset-0" style={{ backgroundColor: 'rgba(0,0,0,0.2)' }} />
        {/* 碗 */}
        <View className="text-8xl relative z-10" style={{ fontSize: '7rem' }}>
          🥣
        </View>
        {/* 面团 */}
        <View
          className="absolute w-20 h-16 rounded-full z-10 ml-8"
          style={{
            backgroundColor: doughColor,
            top: '38%',
            left: '30%',
            transition: 'background-color 0.3s'
          }}
        />
        {/* 搅拌棒 */}
        <View
          className="absolute text-5xl transition-transform duration-75 z-10"
          style={{
            transform: `translate(${stirrerX}px, ${stirrerY}px) rotate(${stirrerAngle}deg)`,
            top: '35%',
            left: '42%'
          }}
        >
          🥄
        </View>
        {/* 提示文字 - 移到游戏框内部底部 */}
        <View className="absolute bottom-2 left-0 right-0 z-20">
          <Text className="text-white text-xs text-center" style={{ textShadow: '0 1px 2px rgba(0,0,0,0.5)' }}>拖动搅拌棒顺时针旋转</Text>
        </View>
      </View>
    </View>
  );
});

// ==================== 压面工序组件 ====================
// 压面机摇把顺时针旋转，传送带动画，转一圈出一个成品向右传送
const PressStage = memo(({ progress, onProgressChange }: { progress: number; onProgressChange: (p: number) => void }) => {
  const [crankAngle, setCrankAngle] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [beltOffset, setBeltOffset] = useState(0);
  const lastAngleRef = useRef(0);
  const centerRef = useRef({ x: 0, y: 0 });
  const lastFullRotationsRef = useRef(0);

  // 2.5圈(900度)满100%，每75度出一个成品，共12个
  const fullRotations = Math.floor(crankAngle / 75);
  const completedDoughs = Math.min(12, fullRotations);

  // 传送带动画
  useEffect(() => {
    if (fullRotations > lastFullRotationsRef.current) {
      // 新的一圈，传送带移动
      setBeltOffset(prev => prev + 20);
      lastFullRotationsRef.current = fullRotations;
    }
  }, [fullRotations]);

  const getAngle = (clientX: number, clientY: number) => {
    const dx = clientX - centerRef.current.x;
    const dy = clientY - centerRef.current.y;
    return Math.atan2(dy, dx) * (180 / Math.PI);
  };

  const handleTouchStart = (e: any) => {
    const touch = e.touches[0];
    centerRef.current = { x: 260, y: 260 };
    lastAngleRef.current = getAngle(touch.clientX, touch.clientY);
    setIsDragging(true);
  };

  const handleTouchMove = (e: any) => {
    if (!isDragging) return;
    const touch = e.touches[0];
    const currentAngle = getAngle(touch.clientX, touch.clientY);
    let delta = currentAngle - lastAngleRef.current;

    if (delta > 180) delta -= 360;
    if (delta < -180) delta += 360;

    // 2.5圈(900度)满100%，每75度出一个成品
    if (delta > 0) {
      setCrankAngle(prev => prev + delta);
      const newProgress = Math.min(100, progress + delta / 9);
      onProgressChange(newProgress);
    }
    lastAngleRef.current = currentAngle;
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };

  return (
    <View className="w-full flex flex-col items-center">
      <Text className="text-dark-brown text-sm mb-2">旋转摇把压面</Text>
      <View className="relative w-full h-56 flex items-center justify-center overflow-hidden rounded-xl">
        {/* 背景图 - 36米压面轨道 */}
        <Image
          src={PRESS_BG}
          className="absolute inset-0 w-full h-full"
          mode="aspectFill"
        />
        {/* 半透明遮罩 */}
        <View className="absolute inset-0" style={{ backgroundColor: 'rgba(0,0,0,0.2)' }} />
        {/* 流水线轨道 - 带传送带动画 */}
        <View className="absolute w-72 h-12 rounded-full overflow-hidden z-10" style={{ border: '3px solid #666', backgroundColor: 'rgba(156,163,175,0.8)' }}>
          {/* 传送带纹理 */}
          <View
            className="absolute w-full h-full flex"
            style={{
              background: 'repeating-linear-gradient(90deg, #666 0px, #666 10px, #888 10px, #888 20px)',
              transform: `translateX(${-beltOffset % 20}px)`,
              transition: 'transform 0.1s linear'
            }}
          />
        </View>

        {/* 面团们 - 从右到左排列，新压出的在右边，共12个 */}
        {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11].map((idx) => {
          const isCompleted = idx < completedDoughs;
          // 从右到左：成品在右边，12个位置
          const positions = [75, 68, 61, 54, 47, 40, 33, 26, 19, 12, 8, 4];
          return (
            <View
              key={idx}
              className="absolute w-8 h-8 rounded-lg flex items-center justify-center transition-all duration-500 z-10"
              style={{
                left: `${positions[idx]}%`,
                backgroundColor: isCompleted ? '#D4A574' : '#F5DEB3',
                transform: isCompleted ? 'scale(0.9)' : 'scale(1)',
                border: '2px solid #8B7355',
                top: '34%',
                opacity: isCompleted ? 1 : 0.3
              }}
            >
              <Text className="text-sm">{isCompleted ? '🍞' : '🟡'}</Text>
            </View>
          );
        })}

        {/* 压面机 */}
        <View className="absolute left-1/2 transform -translate-x-1/2 flex flex-col items-center z-10" style={{ top: '5%' }}>
          <View className="w-20 h-16 bg-gray-600 rounded-lg flex items-center justify-center" style={{ border: '3px solid #333' }}>
            <Text className="text-white text-xs font-bold">压面机</Text>
          </View>
          {/* 入口面团 */}
          <View className="w-10 h-8 rounded-lg bg-yellow-200 mt-1 flex items-center justify-center" style={{ border: '2px solid #8B7355' }}>
            <Text className="text-sm">🟡</Text>
          </View>
        </View>

        {/* 摇把 - 可旋转，去掉背景底 */}
        <View
          className="absolute flex items-center justify-center z-10"
          style={{ right: '5%', top: '45%' }}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        >
          <View
            className="text-7xl transition-transform duration-75"
            style={{ transform: `rotate(${crankAngle}deg)` }}
          >
            🔧
          </View>
        </View>
      </View>

    </View>
  );
});

// ==================== 切割工序组件 ====================
// 大面团竖着切，切开后块往下落进底部藤编篮
const CutStage = memo(({ progress, onProgressChange }: { progress: number; onProgressChange: (p: number) => void }) => {
  const [cutLines, setCutLines] = useState<boolean[]>([false, false, false, false]);
  const [fallenPieces, setFallenPieces] = useState<boolean[]>([false, false, false, false, false]);
  const [knifeX, setKnifeX] = useState(15);
  const [isDragging, setIsDragging] = useState(false);
  const [dragStartX, setDragStartX] = useState(0);

  const linePositions = [20, 40, 60, 80]; // 竖直切割线位置（百分比）
  const totalLines = 4;

  useEffect(() => {
    const completedCount = cutLines.filter(Boolean).length;
    const newProgress = (completedCount / totalLines) * 100;
    onProgressChange(newProgress);
  }, [cutLines]);

  // 切开后触发掉落动画
  useEffect(() => {
    cutLines.forEach((isCut, idx) => {
      if (isCut) {
        // 延迟触发掉落，从左到右依次掉落，速度降低50%
        setTimeout(() => {
          setFallenPieces(prev => {
            const newPieces = [...prev];
            newPieces[idx + 1] = true; // 第idx条切线右侧的块
            return newPieces;
          });
        }, 400 + idx * 300);
      }
    });
  }, [cutLines]);

  const handleTouchStart = (e: any) => {
    const touch = e.touches[0];
    setDragStartX(touch.clientX - knifeX * 3);
    setIsDragging(true);
  };

  const handleTouchMove = (e: any) => {
    if (!isDragging) return;
    const touch = e.touches[0];
    const newX = Math.max(10, Math.min(90, (touch.clientX - dragStartX) / 3));
    setKnifeX(newX);

    // 检测是否经过虚线位置
    linePositions.forEach((pos, idx) => {
      if (Math.abs(newX - pos) < 6 && !cutLines[idx]) {
        setCutLines(prev => {
          const newLines = [...prev];
          newLines[idx] = true;
          return newLines;
        });
      }
    });
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };

  // 计算每个面团块的位置和状态
  const getSectionStyle = (idx: number) => {
    const widths = [20, 20, 20, 20, 20]; // 每块宽度
    const lefts = [0, 20, 40, 60, 80]; // 每块左边距
    const isFallen = fallenPieces[idx];
    const isFirstPiece = idx === 0;
    const hasLeftCut = idx > 0 && cutLines[idx - 1];

    return {
      width: `${widths[idx]}%`,
      left: `${lefts[idx]}%`,
      height: isFallen ? '0%' : '35%',
      top: isFallen ? '60%' : '15%',
      opacity: isFallen ? 0 : 1,
      transform: isFallen ? 'translateY(200px) rotate(15deg)' : 'translateY(0)',
      transition: 'all 0.6s cubic-bezier(0.4, 0, 0.2, 1)',
      backgroundColor: '#F5DEB3',
      borderRight: idx < 4 ? (cutLines[idx] ? '3px solid #8B4513' : '2px dashed #999') : 'none',
      borderLeft: hasLeftCut ? '3px solid #8B4513' : 'none',
      borderRadius: isFirstPiece ? '12px 0 0 12px' : idx === 4 ? '0 12px 12px 0' : '0'
    };
  };

  return (
    <View className="w-full flex flex-col items-center">
      <Text className="text-dark-brown text-sm mb-2">沿虚线竖切面团</Text>
      <View
        className="relative w-full h-72 rounded-2xl overflow-hidden"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* 背景图 - 面团切割 */}
        <Image
          src={CUT_BG}
          className="absolute inset-0 w-full h-full"
          mode="aspectFill"
        />
        {/* 半透明遮罩 */}
        <View className="absolute inset-0" style={{ backgroundColor: 'rgba(0,0,0,0.2)' }} />

        {/* 面团区域容器 */}
        <View className="absolute w-full h-full">
          {/* 面团分段 - 竖向排列，切后掉落 */}
          {[0, 1, 2, 3, 4].map((idx) => (
            <View
              key={idx}
              className="absolute z-10"
              style={getSectionStyle(idx)}
            >
              {/* 面团纹理 */}
              <View className="w-full h-full flex items-center justify-center">
                <Text className="text-2xl opacity-50">🍞</Text>
              </View>
            </View>
          ))}

          {/* 虚线标记 - 竖向 */}
          {linePositions.map((pos, idx) => (
            !cutLines[idx] && (
              <View
                key={idx}
                className="absolute flex flex-col justify-center items-center z-20"
                style={{
                  left: `${pos}%`,
                  top: '15%',
                  height: '35%',
                  transform: 'translateX(-50%)'
                }}
              >
                <Text className="text-gray-500 text-xs" style={{ writingMode: 'vertical-rl' }}>｜｜｜</Text>
              </View>
            )
          ))}

          {/* 切刀 - 水平移动 */}
          <View
            className="absolute flex items-center justify-center z-30"
            style={{
              left: `${knifeX}%`,
              top: '10%',
              transform: 'translateX(-50%)',
              transition: isDragging ? 'none' : 'left 0.2s'
            }}
          >
            <Text className="text-3xl" style={{ transform: 'rotate(90deg)' }}>🔪</Text>
          </View>
        </View>

        {/* 藤编篮 - 底部30% */}
        <View
          className="absolute bottom-0 left-0 right-0 z-20 flex items-end justify-center"
          style={{ height: '30%' }}
        >
          {/* 篮子主体 */}
          <View
            className="w-4/5 h-full relative"
            style={{
              backgroundColor: 'rgba(139, 90, 43, 0.9)',
              borderRadius: '0 0 20px 20px',
              border: '4px solid #654321',
              borderTop: 'none'
            }}
          >
            {/* 藤编纹理 */}
            <View className="absolute inset-0 overflow-hidden" style={{ borderRadius: '0 0 16px 16px' }}>
              {/* 横向编织线 */}
              {[...Array(6)].map((_, i) => (
                <View
                  key={`h-${i}`}
                  className="absolute w-full"
                  style={{
                    height: '3px',
                    backgroundColor: 'rgba(101, 67, 33, 0.6)',
                    top: `${15 + i * 14}%`
                  }}
                />
              ))}
              {/* 纵向编织线 */}
              {[...Array(8)].map((_, i) => (
                <View
                  key={`v-${i}`}
                  className="absolute h-full"
                  style={{
                    width: '3px',
                    backgroundColor: 'rgba(101, 67, 33, 0.5)',
                    left: `${10 + i * 11}%`
                  }}
                />
              ))}
            </View>

            {/* 篮子里的掉落面团 */}
            <View className="absolute inset-0 flex flex-wrap items-end justify-center p-2" style={{ paddingBottom: '8px' }}>
              {fallenPieces.map((hasFallen, idx) => (
                hasFallen && (
                  <View
                    key={idx}
                    className="m-1 flex items-center justify-center"
                    style={{
                      width: '18%',
                      height: '40%',
                      backgroundColor: '#D4A574',
                      borderRadius: '8px',
                      border: '2px solid #8B7355',
                      animation: 'bounceIn 0.5s ease-out'
                    }}
                  >
                    <Text className="text-lg">🍞</Text>
                  </View>
                )
              ))}
            </View>

            {/* 篮子标签 */}
            <View
              className="absolute -top-3 left-1/2 transform -translate-x-1/2 px-3 py-1 rounded-full"
              style={{ backgroundColor: 'rgba(139, 90, 43, 0.95)', border: '2px solid #654321' }}
            >
              <Text className="text-white text-xs font-bold">🧺 成品篮</Text>
            </View>
          </View>
        </View>
      </View>
      <View className="mt-2 text-center">
        <Text className="text-light-brown text-xs">拖动切刀沿虚线竖切，面团会落入篮中</Text>
      </View>
    </View>
  );
});

// ==================== 烘焙工序组件 ====================
// 转式烤箱装满面包，从右往左划使烤箱顺时针旋转，2圈后100%
const BakeStage = memo(({ progress, onProgressChange }: { progress: number; onProgressChange: (p: number) => void }) => {
  const [rotation, setRotation] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const startXRef = useRef(0);
  const startRotationRef = useRef(0);

  const targetRotation = 720; // 2圈

  const handleTouchStart = (e: any) => {
    const touch = e.touches[0];
    startXRef.current = touch.clientX;
    startRotationRef.current = rotation;
    setIsDragging(true);
  };

  const handleTouchMove = (e: any) => {
    if (!isDragging) return;
    const touch = e.touches[0];
    const deltaX = startXRef.current - touch.clientX; // 从右往左划

    if (deltaX > 0) {
      const newRotation = Math.min(targetRotation, startRotationRef.current + deltaX * 1.5);
      setRotation(newRotation);
      onProgressChange((newRotation / targetRotation) * 100);
    }
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };

  // 面包颜色随烘焙进度变化
  const getBreadColor = (idx: number) => {
    const breadProgress = Math.min(100, (progress + idx * 10));
    if (breadProgress < 30) return '#F5DEB3';
    if (breadProgress < 60) return '#DEB887';
    if (breadProgress < 90) return '#CD853F';
    return '#8B4513';
  };

  return (
    <View className="w-full flex flex-col items-center">
      <Text className="text-dark-brown text-sm mb-2">从右往左滑动旋转烤箱</Text>
      <View
        className="relative w-full h-56 flex items-center justify-center overflow-hidden rounded-xl"
        onTouchStart={handleTouchStart}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
      >
        {/* 背景图 - 面包塔 */}
        <Image
          src={BAKE_BG}
          className="absolute inset-0 w-full h-full"
          mode="aspectFill"
        />
        {/* 半透明遮罩 */}
        <View className="absolute inset-0" style={{ backgroundColor: 'rgba(0,0,0,0.2)' }} />
        {/* 烤箱外圈 */}
        <View
          className="absolute w-48 h-48 rounded-full border-8 border-gray-600 flex items-center justify-center overflow-hidden z-10"
          style={{
            background: 'linear-gradient(135deg, #666, #333)',
            transform: `rotate(${rotation}deg)`,
            transition: isDragging ? 'none' : 'transform 0.3s'
          }}
        >
          {/* 烤箱内的面包 - 圆形排列 */}
          {[0, 1, 2, 3, 4, 5].map(i => {
            const angle = (i * 60) * (Math.PI / 180);
            const x = Math.cos(angle) * 55;
            const y = Math.sin(angle) * 55;
            return (
              <View
                key={i}
                className="absolute w-12 h-10 rounded-lg flex items-center justify-center"
                style={{
                  backgroundColor: getBreadColor(i),
                  transform: `translate(${x}px, ${y}px) rotate(-${rotation}deg)`,
                  border: '2px solid #5D4037',
                  transition: 'background-color 0.5s'
                }}
              >
                <Text className="text-xs">🍞</Text>
              </View>
            );
          })}
        </View>

        {/* 中心火焰 */}
        <View className="absolute w-14 h-14 rounded-full bg-orange-500 flex items-center justify-center z-10" style={{ border: '3px solid #8B4513' }}>
          <Text className="text-2xl">🔥</Text>
        </View>

        {/* 滑动提示 */}
        <View className="absolute -bottom-2 flex items-center gap-1 z-10">
          <Text className="text-gray-400 text-xs">👈 右滑左</Text>
        </View>
      </View>
      <View className="mt-2">
        <Text className="text-light-brown text-xs">已旋转 {(rotation / 360).toFixed(1)} / 2 圈</Text>
      </View>
    </View>
  );
});

// ==================== 冷却工序组件 ====================
// 左右滑动吹风按钮，卡通面包烘干机背景，风吹效果
const CoolStage = memo(({ progress, onProgressChange }: { progress: number; onProgressChange: (p: number) => void }) => {
  const [sliderPos, setSliderPos] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const [windParticles, setWindParticles] = useState<{ id: number; x: number; y: number }[]>([]);

  const handleTouchStart = () => {
    setIsDragging(true);
  };

  const handleTouchMove = (e: any) => {
    if (!isDragging) return;
    const touch = e.touches[0];
    // 使用固定容器宽度计算，避免小程序环境window对象问题
    const containerWidth = 300;
    const newPos = Math.max(0, Math.min(100, ((touch.clientX - 40) / containerWidth) * 100));
    setSliderPos(newPos);

    // 滑动时增加进度
    if (newPos > 10 && newPos < 90) {
      onProgressChange(Math.min(100, progress + 0.3));
    }

    // 生成风粒子
    if (Math.random() > 0.6) {
      const newParticle = { id: Date.now() + Math.random(), x: newPos, y: 40 + Math.random() * 30 };
      setWindParticles(prev => [...prev.slice(-8), newParticle]);
    }
  };

  const handleTouchEnd = () => {
    setIsDragging(false);
  };

  // 自动清除风粒子
  useEffect(() => {
    const interval = setInterval(() => {
      setWindParticles(prev => prev.slice(1));
    }, 80);
    return () => clearInterval(interval);
  }, []);

  return (
    <View className="w-full flex flex-col items-center">
      <Text className="text-dark-brown text-sm mb-2">左右滑动吹风冷却</Text>

      {/* 面包区域 */}
      <View className="relative w-full h-28 flex items-center justify-center mb-4 overflow-hidden rounded-xl">
        {/* 背景图 - 烘烤后出炉运送 */}
        <Image
          src={COOL_BG}
          className="absolute inset-0 w-full h-full"
          mode="aspectFill"
        />
        {/* 半透明遮罩 */}
        <View className="absolute inset-0" style={{ backgroundColor: 'rgba(0,0,0,0.2)' }} />
        <View className="flex gap-3 z-10">
          {[0, 1, 2].map(i => (
            <View
              key={i}
              className="w-16 h-14 rounded-lg flex items-center justify-center"
              style={{
                backgroundColor: progress > i * 35 ? '#F5DEB3' : '#8B4513',
                border: '3px solid #5D4037',
                transition: 'background-color 0.5s'
              }}
            >
              <Text className="text-2xl">🍞</Text>
            </View>
          ))}
        </View>

        {/* 风粒子 */}
        {windParticles.map(p => (
          <View
            key={p.id}
            className="absolute text-blue-300 text-lg z-10"
            style={{
              left: `${p.x}%`,
              top: `${p.y}%`,
              opacity: 0.7
            }}
          >
            💨
          </View>
        ))}
      </View>

      {/* 滑动条 - 卡通面包烘干机 */}
      <View className="w-full px-6">
        <View
          className="relative h-20 bg-blue-50 rounded-2xl flex items-center overflow-hidden"
          style={{ border: '3px solid #60A5FA' }}
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        >
          {/* 背景 - 卡通面包烘干机 */}
          <View className="absolute inset-0 flex items-center justify-center opacity-40">
            <Text className="text-6xl">🏭</Text>
          </View>
          <View className="absolute inset-x-0 top-1/2 h-1 bg-blue-200" style={{ transform: 'translateY(-50%)' }} />

          {/* 滑动按钮 */}
          <View
            className="absolute w-16 h-16 bg-blue-500 rounded-xl flex items-center justify-center shadow-lg"
            style={{
              left: `${sliderPos}%`,
              transform: 'translateX(-50%)',
              transition: isDragging ? 'none' : 'left 0.3s'
            }}
          >
            <Text className="text-3xl">🌬️</Text>
          </View>
        </View>
      </View>

      <View className="mt-2 text-center">
        <Text className="text-light-brown text-xs">左右滑动按钮吹风冷却</Text>
      </View>
    </View>
  );
});

// ==================== 包装工序组件 ====================
// 折叠箱子方式 - 点击折叠箱子的各个面
const PackageStage = memo(({ progress, onProgressChange }: { progress: number; onProgressChange: (p: number) => void }) => {
  const [foldedSides, setFoldedSides] = useState<boolean[]>([false, false, false, false, false]);

  const handleFoldSide = (sideIndex: number) => {
    if (foldedSides[sideIndex]) return; // 已折叠的不能重复点击

    const newFoldedSides = [...foldedSides];
    newFoldedSides[sideIndex] = true;
    setFoldedSides(newFoldedSides);

    const foldedCount = newFoldedSides.filter(Boolean).length;
    onProgressChange((foldedCount / 5) * 100);
  };

  const resetBox = () => {
    setFoldedSides([false, false, false, false, false]);
    onProgressChange(0);
  };

  return (
    <View className="w-full flex flex-col items-center">
      <Text className="text-dark-brown text-sm mb-2">点击折叠箱子完成包装</Text>
      <View className="relative w-full h-56 flex items-center justify-center overflow-hidden rounded-xl">
        {/* 背景图 - 装箱 */}
        <Image
          src={PACKAGE_BG}
          className="absolute inset-0 w-full h-full"
          mode="aspectFill"
        />
        {/* 半透明遮罩 */}
        <View className="absolute inset-0" style={{ backgroundColor: 'rgba(0,0,0,0.2)' }} />
        {/* 纸箱底板 */}
        <View
          className="absolute w-40 h-32 rounded-sm z-10"
          style={{ border: '2px solid #8B7355', backgroundColor: 'rgba(253,230,138,0.9)' }}
        />

        {/* 待折叠的箱面 - 底面(0), 左面(1), 右面(2), 前面(3), 后面(4) */}
        {/* 底面 - 先折 */}
        <View
          className="absolute w-36 h-24 rounded-sm flex items-center justify-center cursor-pointer"
          style={{
            border: '3px solid #5D4037',
            backgroundColor: foldedSides[0] ? 'rgba(252,211,77,0.7)' : 'rgba(255,193,7,0.95)',
            transform: foldedSides[0] ? 'translateY(10px) scale(0.95)' : 'translateY(0)',
            opacity: foldedSides[0] ? 0.7 : 1,
            top: '35%',
            zIndex: 50,
            boxShadow: foldedSides[0] ? 'none' : '0 4px 12px rgba(0,0,0,0.3)'
          }}
          onClick={() => handleFoldSide(0)}
        >
          {!foldedSides[0] && (
            <View className="flex flex-col items-center">
              <Text className="text-amber-900 text-sm font-bold">点击折底</Text>
              <Text className="text-amber-700 text-xs mt-1">👆 先折这里</Text>
            </View>
          )}
          {foldedSides[0] && <Text className="text-2xl">📦</Text>}
        </View>

        {/* 左面 */}
        {!foldedSides[1] && (
          <View
            className="absolute w-10 h-24 rounded-sm flex items-center justify-center z-10"
            style={{ border: '2px solid #8B7355', backgroundColor: 'rgba(252,211,77,0.9)', left: '15%', top: '20%', zIndex: 10 }}
            onClick={() => handleFoldSide(1)}
          >
            <Text className="text-amber-800 text-xs transform -rotate-90">左</Text>
          </View>
        )}

        {/* 右面 */}
        {!foldedSides[2] && (
          <View
            className="absolute w-10 h-24 rounded-sm flex items-center justify-center z-10"
            style={{ border: '2px solid #8B7355', backgroundColor: 'rgba(252,211,77,0.9)', right: '15%', top: '20%', zIndex: 10 }}
            onClick={() => handleFoldSide(2)}
          >
            <Text className="text-amber-800 text-xs transform rotate-90">右</Text>
          </View>
        )}

        {/* 前面 */}
        {!foldedSides[3] && (
          <View
            className="absolute w-36 h-10 rounded-sm flex items-center justify-center z-10"
            style={{ border: '2px solid #8B7355', backgroundColor: 'rgba(252,211,77,0.9)', bottom: '15%', left: '20%', zIndex: 10 }}
            onClick={() => handleFoldSide(3)}
          >
            <Text className="text-amber-800 text-xs">前</Text>
          </View>
        )}

        {/* 后面 */}
        {!foldedSides[4] && (
          <View
            className="absolute w-36 h-10 rounded-sm flex items-center justify-center z-10"
            style={{ border: '2px solid #8B7355', backgroundColor: 'rgba(252,211,77,0.9)', top: '10%', left: '20%', zIndex: 10 }}
            onClick={() => handleFoldSide(4)}
          >
            <Text className="text-amber-800 text-xs">后</Text>
          </View>
        )}

        {/* 已完成的箱子显示 */}
        {foldedSides.every(Boolean) && (
          <View
            className="absolute w-40 h-32 rounded-lg flex items-center justify-center z-20"
            style={{ border: '3px solid #5D4037', backgroundColor: 'rgba(251,191,36,0.9)' }}
          >
            <View className="flex flex-wrap gap-1 justify-center p-2">
              {[0, 1, 2, 3, 4, 5].map(i => (
                <Text key={i} className="text-lg">🍞</Text>
              ))}
            </View>
            <View className="absolute w-44 h-6 bg-red-500 rounded" style={{ top: '40%' }} />
            <View className="absolute w-6 h-36 bg-red-500 rounded" style={{ left: '42%' }} />
          </View>
        )}
      </View>

      {/* 折叠进度 */}
      <View className="mt-2 flex gap-1">
        {['底', '左', '右', '前', '后'].map((label, i) => (
          <View
            key={i}
            className={`w-10 h-8 rounded flex items-center justify-center ${foldedSides[i] ? 'bg-quinoa-red' : 'bg-gray-300'}`}
            style={{ border: '1px solid #8B7355' }}
          >
            <Text className="text-white text-xs">{foldedSides[i] ? '✓' : label}</Text>
          </View>
        ))}
      </View>

      {foldedSides.every(Boolean) && (
        <View className="mt-2" onClick={resetBox}>
          <Text className="text-quinoa-red text-xs">箱子已折叠完成！</Text>
        </View>
      )}
    </View>
  );
});

// 工序指示器 - 可点击选择
const StageIndicator = memo(({
  stages,
  currentStage,
  onStageClick,
  expectedStage
}: {
  stages: Stage[];
  currentStage: number;
  onStageClick: (idx: number) => void;
  expectedStage: number;
}) => {
  return (
    <View className="flex justify-center gap-2 mt-4">
      {stages.map((stage, idx) => {
        const isCompleted = stage.completed;
        const isActive = idx === currentStage;
        const isClickable = true; // 所有工序都可点击

        return (
          <View
            key={stage.id}
            className="flex flex-col items-center"
            onClick={() => onStageClick(idx)}
          >
            <View
              className={`w-12 h-12 rounded-full flex items-center justify-center transition-all duration-300 ${
                isCompleted ? 'bg-cream-green' : isActive ? 'bg-quinoa-red scale-110' : 'bg-muted'
              } ${isClickable ? 'cursor-pointer' : ''}`}
              style={{
                border: isActive ? '3px solid #FFC65C' : isCompleted ? '2px solid #22C55E' : '2px solid #E8D5C4'
              }}
            >
              <Text className="text-xl">{isCompleted ? '✓' : stage.icon}</Text>
            </View>
            <Text className={`text-xs mt-1 ${isActive ? 'text-quinoa-red font-bold' : 'text-light-brown'}`}>
              {stage.name}
            </Text>
          </View>
        );
      })}
    </View>
  );
});

// 提示弹窗
const Toast = memo(({ message, visible, onClose }: { message: string; visible: boolean; onClose: () => void }) => {
  useEffect(() => {
    if (visible) {
      const timer = setTimeout(onClose, 2000);
      return () => clearTimeout(timer);
    }
  }, [visible, onClose]);

  if (!visible) return null;

  return (
    <View
      className="absolute top-1/3 left-1/2 transform -translate-x-1/2 px-6 py-3 bg-gray-800 rounded-xl z-50"
      style={{ animation: 'fade-in 0.3s ease-out' }}
    >
      <Text className="text-white text-sm font-bold">{message}</Text>
    </View>
  );
});

// 当前工序展示
const CurrentStageView = memo(({
  stage,
  progress,
  onProgressChange
}: {
  stage: Stage;
  progress: number;
  onProgressChange: (p: number) => void;
}) => {
  const renderStage = () => {
    switch (stage.id) {
      case 'dough':
        return <DoughStage progress={progress} onProgressChange={onProgressChange} />;
      case 'press':
        return <PressStage progress={progress} onProgressChange={onProgressChange} />;
      case 'cut':
        return <CutStage progress={progress} onProgressChange={onProgressChange} />;
      case 'bake':
        return <BakeStage progress={progress} onProgressChange={onProgressChange} />;
      case 'cool':
        return <CoolStage progress={progress} onProgressChange={onProgressChange} />;
      case 'package':
        return <PackageStage progress={progress} onProgressChange={onProgressChange} />;
      default:
        return null;
    }
  };

  return (
    <View className="w-full">
      <View className="relative w-full h-72 rounded-2xl overflow-hidden bg-white" style={{ border: '4px solid #FFE9C7' }}>
        <View className="absolute inset-0 flex flex-col items-center justify-center p-4">
          {renderStage()}
        </View>
      </View>
      {/* 进度条 */}
      <View className="mt-3 w-full h-4 bg-gray-200 rounded-full overflow-hidden" style={{ border: '2px solid #E8D5C4' }}>
        <View
          className="h-full rounded-full transition-all duration-200"
          style={{
            width: `${progress}%`,
            background: 'linear-gradient(90deg, #E96F4D, #FFC65C)'
          }}
        />
      </View>
      <View className="flex justify-between mt-1">
        <Text className="text-dark-brown text-sm font-bold">{stage.name}进度</Text>
        <Text className="text-quinoa-red font-bold">{Math.floor(progress)}%</Text>
      </View>
    </View>
  );
});

const Level3Page = () => {
  const [gameState, setGameState] = useState<'ready' | 'playing' | 'completed'>('ready');
  const [score, setScore] = useState(0);
  const [currentStage, setCurrentStage] = useState(0);
  const [stages, setStages] = useState<Stage[]>(STAGES_CONFIG.map(s => ({ ...s })));
  const [toast, setToast] = useState({ visible: false, message: '' });
  const [showEncouragement, setShowEncouragement] = useState(false);
  const [encouragementText, setEncouragementText] = useState('');
  const encouragementTimerRef = useRef<NodeJS.Timeout | null>(null);

  // 计算期望的下一个工序
  const getExpectedStage = () => {
    for (let i = 0; i < stages.length; i++) {
      if (!stages[i].completed) return i;
    }
    return stages.length - 1;
  };

  const expectedStage = getExpectedStage();

  const showToast = (message: string) => {
    setToast({ visible: true, message });
  };

  const hideToast = () => {
    setToast({ visible: false, message: '' });
  };

  // 显示鼓励文案
  const showEncouragementMessage = (text: string, duration: number = 4000) => {
    // 清除之前的定时器
    if (encouragementTimerRef.current) {
      clearTimeout(encouragementTimerRef.current);
    }
    setEncouragementText(text);
    setShowEncouragement(true);
    encouragementTimerRef.current = setTimeout(() => {
      setShowEncouragement(false);
    }, duration);
  };

  // 处理工序点击
  const handleStageClick = (idx: number) => {
    if (gameState !== 'playing') return;

    // 检查是否按顺序进行
    if (idx !== expectedStage) {
      showToast('请按工序进行哦~');
      return;
    }

    setCurrentStage(idx);

    // 进入烘焙工序时显示鼓励文案
    if (stages[idx].id === 'bake' && !stages[idx].completed) {
      showEncouragementMessage('它在里面悄悄膨胀，就像你那些暂时看不到回报的坚持。面包需要时间才能又香又甜。');
    }
  };

  const handleProgressChange = useCallback((progress: number) => {
    setStages(prev => {
      const newStages = [...prev];
      const activeIdx = currentStage;
      if (activeIdx !== -1) {
        newStages[activeIdx].progress = progress;
        if (progress >= 100 && !newStages[activeIdx].completed) {
          newStages[activeIdx].completed = true;
          setScore(s => s + 20);

          // 烘焙工序完成时显示鼓励文案
          if (newStages[activeIdx].id === 'bake') {
            showEncouragementMessage('叮！所有的好结果都终将到来。', 3000);
          }

          // 自动切换到下一个未完成的工序
          const nextIdx = activeIdx + 1;
          if (nextIdx < newStages.length) {
            setTimeout(() => setCurrentStage(nextIdx), 500);
          }
        }
      }
      return newStages;
    });
  }, [currentStage]);

  // 检查是否全部完成
  useEffect(() => {
    const allCompleted = stages.every(s => s.completed);
    if (allCompleted && gameState === 'playing') {
      setTimeout(() => {
        setGameState('completed');
        saveProgress();
      }, 500);
    }
  }, [stages, gameState]);

  const startGame = () => {
    setGameState('playing');
    setScore(0);
    setCurrentStage(0);
    setStages(STAGES_CONFIG.map(s => ({ ...s })));
  };

  const saveProgress = () => {
    const progress = Taro.getStorageSync('gameProgress');
    const data = progress ? JSON.parse(progress) : { levels: [], score: 0 };
    data.levels = data.levels || [];
    data.levels[2] = { id: 3, completed: true, unlocked: true };
    data.levels[3] = { id: 4, completed: false, unlocked: true };
    data.score = (data.score || 0) + score + 100;
    Taro.setStorageSync('gameProgress', JSON.stringify(data));
  };

  const nextLevel = () => {
    // 跳转到结果页，带上显示商店的参数
    Taro.redirectTo({ url: '/pages/result/index?showShop=true' });
  };

  const backToMenu = () => {
    Taro.redirectTo({ url: '/pages/game/index' });
  };

  const activeStage = stages[currentStage];

  return (
    <View className="min-h-screen w-full flex flex-col bg-background relative overflow-hidden">
      {/* 顶部导航 */}
      <View className="flex items-center justify-between px-4 py-3 bg-wheat-yellow">
        <View className="flex items-center" onClick={backToMenu}>
          <Image src={HAOSHI_LOGO} className="w-24 h-12 object-contain" mode="aspectFit" />
        </View>
        <View className="flex items-center gap-2">
          <Text className="text-gold text-xl">🪙</Text>
          <Text className="text-dark-brown font-bold">{score}</Text>
        </View>
      </View>

      {/* 关卡标题 */}
      <View className="flex flex-col items-center py-4 bg-gradient-to-b from-wheat-yellow to-background">
        <Text className="text-dark-brown text-2xl font-bold">关卡 3</Text>
        <Text className="text-quinoa-red text-xl font-bold">烘焙流水线</Text>
        <Text className="text-light-brown text-sm mt-1">点击工序图标切换，按顺序完成</Text>
      </View>

      {/* 游戏区域 */}
      <View className="flex-1 flex flex-col items-center px-4 py-2">
        {/* 流水线标题 */}
        <View className="flex items-center gap-2 mb-3">
          <Text className="text-2xl">🏭</Text>
          <Text className="text-dark-brown font-bold">豪士透明工厂</Text>
          <Text className="text-2xl">🏭</Text>
        </View>

        {/* 当前工序展示 */}
        {gameState === 'playing' && (
          <View className="w-full mb-4">
            <CurrentStageView
              stage={activeStage}
              progress={activeStage.progress}
              onProgressChange={handleProgressChange}
            />
          </View>
        )}

        {/* 工序指示器 - 可点击 */}
        <StageIndicator
          stages={stages}
          currentStage={currentStage}
          onStageClick={handleStageClick}
          expectedStage={expectedStage}
        />

        {/* 提示 */}
        <View className="mt-4 bg-white rounded-xl p-3 shadow-sm" style={{ border: '2px solid #FFE9C7' }}>
          <Text className="text-dark-brown text-sm text-center">
            点击上方工序图标可切换，但<Text className="text-quinoa-red font-bold">必须按顺序</Text>完成
          </Text>
        </View>

      </View>

      {/* 提示弹窗 */}
      <Toast message={toast.message} visible={toast.visible} onClose={hideToast} />

      {/* 鼓励文案弹窗 */}
      {showEncouragement && (
        <View className="absolute top-20 left-4 right-4 z-50" style={{ animation: 'pop-in 0.5s ease-out' }}>
          <View className="bg-white rounded-2xl p-4 shadow-lg" style={{ backgroundColor: 'rgba(255,255,255,0.95)', boxShadow: '0 4px 20px rgba(0,0,0,0.15)' }}>
            <Text className="text-dark-brown text-sm text-center leading-relaxed">{encouragementText}</Text>
          </View>
        </View>
      )}

      {/* 开始遮罩 */}
      {gameState === 'ready' && (
        <View
          className="absolute inset-0 flex items-center justify-center"
          style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}
        >
          <View className="bg-white rounded-3xl p-8 flex flex-col items-center mx-6">
            <Text className="text-4xl mb-4">🏭</Text>
            <Text className="text-dark-brown text-lg font-bold mb-2">烘焙流水线</Text>
            <Text className="text-light-brown text-sm mb-2 text-center">
              欢迎来到豪士透明工厂！
            </Text>
            <Text className="text-quinoa-red text-sm mb-4 text-center font-bold">
              每个工序都有独特操作{'\n'}按顺序完成所有工序！
            </Text>
            <View
              className="px-8 py-3 rounded-full"
              style={{ background: 'linear-gradient(135deg, #E96F4D, #FFC65C)' }}
              onClick={startGame}
            >
              <Text className="text-white font-bold">开始生产</Text>
            </View>
          </View>
        </View>
      )}

      {/* 完成遮罩 */}
      {gameState === 'completed' && (
        <View
          className="absolute inset-0 flex items-center justify-center"
          style={{ backgroundColor: 'rgba(0,0,0,0.5)' }}
        >
          <View className="bg-white rounded-3xl p-8 flex flex-col items-center mx-6">
            <Text className="text-4xl mb-4">🎊</Text>
            <Text className="text-dark-brown text-lg font-bold mb-2">关卡完成！</Text>
            <Text className="text-quinoa-red text-xl font-bold mb-4">
              流水线生产成功
            </Text>
            <Text className="text-light-brown text-sm mb-6">
              获得 {score + 100} 金币
            </Text>
            <View
              className="px-8 py-3 rounded-full mb-3"
              style={{ background: 'linear-gradient(135deg, #E96F4D, #FFC65C)' }}
              onClick={nextLevel}
            >
              <Text className="text-white font-bold">查看成果</Text>
            </View>
            <View
              className="px-8 py-3 rounded-full bg-muted"
              onClick={backToMenu}
            >
              <Text className="text-dark-brown">返回菜单</Text>
            </View>
          </View>
        </View>
      )}
    </View>
  );
};

export default Level3Page;
